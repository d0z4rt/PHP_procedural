<?php
namespace App\Model;


class User extends Model
{
    // protected string $table = 'User';




}
