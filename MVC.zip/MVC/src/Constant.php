<?php
namespace App;

class Constant
{
    public const DB_NAME = "oop";
    public const DB_HOST = "127.0.0.1";
    public const DB_USERNAME = 'root';
    public const DB_PASSWORD = 'root';
}